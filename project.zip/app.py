from flask import Flask, render_template, url_for, request,send_from_directory
import joblib

app = Flask(__name__)

model = joblib.load('best_rf_classifier (1).pkl')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['GET','POST'])
def predict():
    print('something')
    if request.method == 'POST' :
        print(request.method)
        print(request.form.values())
        Loan_Amount = request.form['loan'] # requesting loan amount
        Term = request.form['term'] # requesting for terms of loan
        lender_count = request.form['Country'] # requesting lender count
        Male = request.form['Male'] # requesting male count
        Female = request.form['Female'] # requesting female count
        disbursed_time = request.form['disbursed_time']
        country_code = request.form['country_code']
        sector = request.form['sector']
        region  = request.form['region']
        activity = request.form['activity']

        X = [[int(Loan_Amount),int(Term),int(lender_count),int(Male),int(Female)]]
        prediction = model.predict(X) 
        print(prediction)
        
        return render_template("index.html",prediction='Loan Type  {}'.format(prediction[0]))
    
    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True)
